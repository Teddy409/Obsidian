# Geburtstagsparty organisieren – Projektplan

## Ausgangslage

Ein Kollege wird in ca. 3 Monaten 30 Jahre alt.  
Er möchte ein grosses Fest mit ungefähr **100 Personen** organisieren.  
Bis jetzt ist noch nichts entschieden.

---

## 1. Was würde ich zuerst fragen?

Bevor ich etwas buche, würde ich mit dem Geburtstagskind diese Fragen klären:

### Budget
- Wie viel Geld darf die Party insgesamt kosten?
- Gibt es eine feste Obergrenze?
- Soll jeder Gast etwas bezahlen oder übernimmt alles das Geburtstagskind?

### Gäste
- Wie viele Personen werden ungefähr eingeladen?
- Sind Kinder dabei?
- Gibt es ältere Personen, für die Sitzplätze wichtig sind?

### Ort
- Soll die Party **drinnen oder draussen** stattfinden?
- Gibt es schon einen Wunschort?
- Gibt es genügend Parkplätze?
- Ist der Ort gut mit öffentlichen Verkehrsmitteln erreichbar?
- Falls Outdoor: Was machen wir bei Regen?

### Essen und Getränke
- Buffet, Grill, Catering oder selbst kochen?
- Gibt es Vegetarier oder Veganer?
- Gibt es Allergien oder Unverträglichkeiten?
- Welche Getränke sollen angeboten werden?
- Brauchen wir eine Geburtstagstorte?

### Motto und Dekoration
- Soll die Party ein Motto haben?
- Welche Farben oder Dekoration gefallen dem Geburtstagskind?
- Soll es eher elegant, locker oder lustig sein?

### Musik
- Welche Musikrichtung mag das Geburtstagskind?
- Soll ein DJ kommen oder reicht eine Playlist?
- Soll später getanzt werden?
- Wie laut darf die Musik am Veranstaltungsort sein?

### Programm
- Soll es Spiele geben?
- Gibt es Reden oder Überraschungen?
- Soll eine Fotobox aufgebaut werden?
- Wann beginnt und wann endet die Party?

---

# 2. Meine Empfehlung

Für ungefähr **100 Personen** würde ich eine **Halle oder einen grossen Partyraum** nehmen.

Warum?

- Das Wetter spielt keine Rolle.
- Toiletten und Strom sind normalerweise vorhanden.
- Essen, Musik und Technik sind leichter zu organisieren.
- Man braucht keinen grossen Notfallplan wegen Regen.
- Eine Feier mit 100 Personen ist draussen organisatorisch schwieriger.

Wenn die Party im Sommer stattfindet, wäre ideal:

**Halle mit zusätzlichem Aussenbereich.**

Dann können die Gäste draussen sitzen, aber bei schlechtem Wetter nach drinnen gehen.

---

# 3. Idee für die Party

## Motto

### „30 Jahre – Black & Gold Party“

Warum dieses Motto?

- Einfach zu dekorieren.
- Sieht festlich aus.
- Passt gut zu einem 30. Geburtstag.
- Gäste können normale Kleidung tragen.
- Farben: Schwarz, Gold und Weiss.

Dekoration:

- Ballons mit der Zahl 30
- Schwarze und goldene Tischdecken
- Lichterketten
- Fotos aus verschiedenen Lebensjahren
- Kleine Foto-Ecke / Fotobox

---

# 4. Essen

Für 100 Personen würde ich **kein kompliziertes Menü am Tisch** machen.

Meine Wahl wäre ein **Buffet**.

## Beispiel Buffet

### Hauptessen
- Poulet
- Grillwürste
- Veggie-Burger oder Gemüse
- Kartoffelgratin oder Pommes
- Reis

### Beilagen
- Gemischter Salat
- Tomaten-Mozzarella
- Brot
- Verschiedene Saucen

### Dessert
- Geburtstagstorte
- Muffins
- Früchte
- Kleine Desserts im Glas

### Getränke
- Wasser
- Cola / Cola Zero
- Eistee
- Orangensaft
- Kaffee

Falls alkoholische Getränke angeboten werden, sollte vorher geklärt werden, was das Geburtstagskind möchte und wer dafür verantwortlich ist.

---

# 5. Musik

Ich würde Musik wählen, die für viele Altersgruppen funktioniert.

## Musikrichtungen

- Charts
- Pop
- 80er
- 90er
- 2000er
- aktuelle Partyhits
- etwas Rock
- auf Wunsch Hip-Hop / R&B

## Ablauf der Musik

**Beim Essen:**  
Ruhigere Hintergrundmusik.

**Nach dem Essen:**  
Bekannte Songs und Partyhits.

**Später am Abend:**  
Tanzmusik.

Für 100 Personen wäre ein **DJ** cool, wenn das Budget reicht.  
Sonst reicht auch eine gute Spotify-Playlist mit Lautsprechern.

---

# 6. Grober Ablauf der Party

| Zeit | Programmpunkt |
|---|---|
| 17:00 | Aufbau und letzte Vorbereitungen |
| 18:00 | Gäste kommen an |
| 18:30 | Begrüssung |
| 19:00 | Buffet / Abendessen |
| 20:30 | Rede / Überraschung / Fotos |
| 21:00 | Geburtstagstorte |
| 21:30 | Musik und Party |
| 00:00 | Mitternachtssnack |
| 01:00–02:00 | Ende / Aufräumen |

---

# 7. Organisation – Schritt für Schritt

## 3 Monate vorher
- [ ] Budget festlegen
- [ ] Gästeliste erstellen
- [ ] Datum festlegen
- [ ] Halle / Partyraum suchen
- [ ] Ort reservieren
- [ ] Motto bestimmen

## 2 Monate vorher
- [ ] Einladungen verschicken
- [ ] Essen / Catering organisieren
- [ ] DJ oder Musik organisieren
- [ ] Dekoration planen
- [ ] Tische und Stühle klären
- [ ] Technik prüfen

## 1 Monat vorher
- [ ] Anzahl Gäste kontrollieren
- [ ] Menü endgültig festlegen
- [ ] Getränke bestellen
- [ ] Torte bestellen
- [ ] Programm planen
- [ ] Helfer bestimmen

## 1 Woche vorher
- [ ] Gästezahl bestätigen
- [ ] Einkaufsliste kontrollieren
- [ ] Musik / Playlist testen
- [ ] Dekoration vorbereiten
- [ ] Aufgaben an Helfer verteilen

## Am Tag der Party
- [ ] Raum dekorieren
- [ ] Tische und Stühle aufstellen
- [ ] Musik und Technik testen
- [ ] Buffet vorbereiten
- [ ] Getränke kaltstellen
- [ ] Eingang vorbereiten
- [ ] Müllsäcke und Reinigung organisieren

## Nach der Party
- [ ] Aufräumen
- [ ] Müll entsorgen
- [ ] Halle kontrollieren
- [ ] Geliehene Sachen zurückgeben
- [ ] Rechnungen bezahlen

---

# 8. Aufgaben im Team verteilen

Bei einer Gruppenarbeit würde ich die Aufgaben verteilen.

| Person | Aufgabe |
|---|---|
| Person 1 | Location und Budget |
| Person 2 | Essen und Getränke |
| Person 3 | Musik und Technik |
| Person 4 | Dekoration und Motto |
| Person 5 | Gästeliste, Einladungen und Programm |

---

# 9. Dinge, die man nicht vergessen darf

- Genügend Sitzplätze
- Toiletten
- Parkplätze
- Öffentliche Verkehrsmittel
- Stromanschlüsse
- Lautsprecher
- Verlängerungskabel
- Kühlung für Getränke
- Müllsäcke
- Erste-Hilfe-Set
- Notfallplan
- Verantwortliche Helfer
- Abklärung der Lautstärke / Nachtruhe
- Plan B bei schlechtem Wetter

---

# 10. Kurze Präsentation für die Schule

## Folie 1 – Ausgangslage
- 30. Geburtstag
- ca. 100 Gäste
- Planung innerhalb von 3 Monaten

## Folie 2 – Erste Fragen
- Budget
- Gäste
- Ort
- Essen
- Motto
- Musik

## Folie 3 – Unsere Entscheidung
- Halle mit Aussenbereich
- Black & Gold Motto
- Buffet
- gemischte Partymusik

## Folie 4 – Organisation
- Location reservieren
- Einladungen verschicken
- Catering organisieren
- Musik und Technik planen
- Dekoration vorbereiten

## Folie 5 – Zeitplan
- 3 Monate vorher
- 2 Monate vorher
- 1 Monat vorher
- 1 Woche vorher
- Tag der Party

## Folie 6 – Fazit
Eine gute Party braucht:
- klare Aufgaben
- einen Zeitplan
- ein Budget
- einen Plan B
- gute Zusammenarbeit

---

# Fazit

Ich würde **zuerst Budget, Gästezahl, Ort, Essen, Musik und Wünsche des Geburtstagskindes klären**.

Danach würde ich die Location reservieren, weil ein geeigneter Raum für 100 Personen schnell ausgebucht sein kann.

Meine konkrete Idee wäre:

**Black & Gold Party in einer Halle mit Aussenbereich, Buffet, Geburtstagstorte und einer Mischung aus bekannten Partyhits.**
